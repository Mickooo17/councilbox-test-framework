import * as f from './fixtures';
import { expect } from '@playwright/test';
import { resolveCompanyUrl } from '../utils/UrlHelper';

/**
 * Home Page Test Suite
 * Contains all tests related to home page functionality
 */

f.test.describe('HomePage - Navigation Tests', () => {
  f.test.beforeEach(async ({ homePage }) => {
    await homePage.validateHomePageIsOpened();
  });

  f.test('should load home page after successful login @smoke', async ({ homePage }) => {
    // Assert
    await homePage.validateHomePageIsOpened();
  });

  f.test('should display profile icon on home page @smoke @regression', async ({ homePage }) => {
    // Assert
    await homePage.verifyProfileIconIsAccessible();
  });
});

f.test.describe('HomePage - User Profile Tests', () => {
  f.test.beforeEach(async ({ homePage }) => {
    await homePage.validateHomePageIsOpened();
  });

  f.test('should have accessible profile dropdown @regression', async ({ homePage }) => {
    // Assert
    const profileIcon = homePage.profileIcon;
    await expect(profileIcon).toBeVisible();
    await expect(profileIcon).toBeEnabled();
  });

  f.test('The user\'s role is displayed when you hover over the "Account" icon @XR-2524 @smoke @regression', async ({ homePage }) => {
    // 1. Hover over the "Account" icon in the header
    await homePage.hoverAccountIcon();

    // 2. Verify the user's role is displayed in the tooltip [Super administrator/Administrator/Professional/Calendar manager]
    await homePage.verifyRoleDisplayedOnHover(/administrator|admin|super administrator|global administrator|professional|calendar manager/i);
  });

  f.test('Only the Super administrator and Administrator can configure the organization/entity from the "Account" icon @XR-2521 @OVAC-5603 @smoke @regression', async ({ homePage, page }) => {
    // 1. Click on Account icon in header
    await homePage.openAccountMenu();

    // 2. Verify organization/entity configuration option is displayed for administrator
    await homePage.verifyOrganizationConfigOptionVisible(true);

    // 3. Click organization configuration option
    await homePage.clickOrganizationConfigOption();

    // 4. Verify user is redirected to organization configuration page
    await expect(page).toHaveURL(/.*\/companies\/edit\/.*/i, { timeout: 15000 });
  });

  f.test('The Professional and Calendar managers don\'t see the Organization/Entity configuration under the "Account" icon @XR-2522 @OVAC-5600 @regression', async ({ homePage, page }) => {
    // 1. Simulate non-admin role (Professional)
    await homePage.simulateUserRole('professional');

    // 2. Open Account dropdown menu
    await homePage.openAccountMenu();

    // 3. Verify organization/entity configuration option is NOT displayed for Professional
    await homePage.verifyOrganizationConfigOptionVisible(false);

    // 4. Verify common options (Support, End session) are still displayed
    const menu = page.locator('.MuiPopover-root, [role="menu"], .cbx-header-dropdown').first();
    await expect(menu.getByText(/Support|Soporte/i)).toBeVisible();
    await expect(menu.getByText(/End session|Cerrar sesión|Logout/i)).toBeVisible();
  });

  f.test("The organization or entity's logo should to be shown at the top of the all pages @XR-2886 @OVAC-5359 @regression", async ({ homePage, page }) => {
    // 1-2. Verify home page loaded with logo
    await homePage.verifyHeaderLogoVisible();

    // 3-8. Verify logo visible at top across core sections: Dashboard, Activity, Procedures, Templates, Users
    const routes = [
      'activity/dashboardCouncils',
      'activity',
      'procedures',
      'drafts',
      'users'
    ];

    for (const route of routes) {
      await page.goto(resolveCompanyUrl(1112, route), { waitUntil: 'domcontentloaded' });
      await homePage.dismissToastOrModal();
      await homePage.verifyHeaderLogoVisible();
    }
  });

  f.test('Admin is able to Log out from the page @XR-1361 @OVAC-5656 @smoke @regression', async ({ homePage }) => {
    // 1-2. Verify user is on home page
    await homePage.validateHomePageIsOpened();

    // 3. Click on the "Account" icon
    await homePage.openAccountMenu();

    // 4. Click on the "Sign off" button and verify redirect to login page
    await homePage.clickSignOff();
  });

  f.test('When we hover over the name of a document, procedure, entity, template, or user, the entire name is shown @OVAC-5750 @regression', async ({ proceduresPage }) => {
    f.test.slow();
    // 1-4. Hover over procedure name in table list and verify full name or tooltip
    await proceduresPage.verifyHoverProcedureNameTooltip();
  });

  f.test('The user is able to log out from the page - Account section @OVAC-5783 @regression', async ({ homePage }) => {
    // 1-4. Validate user is logged in on home page
    await homePage.validateHomePageIsOpened();

    // 5. Click on the Account icon to display drop-menu
    await homePage.openAccountMenu();

    // 6. Click on the Log out button and verify redirect to login page
    await homePage.clickSignOff();
  });

  f.test('Verify that Agent with video attention is not able to see "Entities" button in the navigation bar @OVAC-5037 @regression', async ({ homePage, page }) => {
    // 1-2. Simulate Agent with video attention role
    await homePage.simulateUserRole('appointmentAgent');

    // 3. Verify Appointments remains visible while Entities navigation link/button is not visible
    await expect(page.getByRole('link', { name: /Appointments/i }).first()).toBeVisible({ timeout: 10000 });
    await expect(page.getByRole('link', { name: /Entities|Institutions/i })).toHaveCount(0, { timeout: 10000 });
    await expect(page.locator('a[href*="/companies"]:visible, button:visible:has-text("Entities"), button:visible:has-text("Institutions")')).toHaveCount(0, { timeout: 10000 });
  });

  f.test('Verify that Entity administrator can see the "Entities" button in the navigation bar @OVAC-5033 @regression', async ({ homePage, page }) => {
    // 1. Simulate Entity Administrator role
    await homePage.simulateUserRole('admin');

    // 2. Verify Entities button in the navigation bar is visible, enabled, and navigates to /companies
    const entitiesNav = page.getByRole('link', { name: /Entities|Institutions/i }).first();
    await expect(entitiesNav).toBeVisible({ timeout: 10000 });
    await expect(entitiesNav).toBeEnabled();

    await entitiesNav.click();
    await expect(page).toHaveURL(/\/companies/i, { timeout: 15000 });
    await expect(page.locator('table tbody tr').first()).toBeVisible({ timeout: 15000 });
  });
});



