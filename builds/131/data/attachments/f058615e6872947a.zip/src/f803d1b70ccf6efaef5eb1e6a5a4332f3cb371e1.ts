import * as path from 'path';
import { Page, Locator, expect, test } from '@playwright/test';
import { BasePage } from '../BasePage';
import { MESSAGES } from '../../utils/Constants';
import { resolveCompanyUrl } from '../../utils/UrlHelper';

export interface InstitutionData {
    name: string;
    cif: string;
    address: string;
    zipCode: string;
    city: string;
}

export class InstitutionsPage extends BasePage {
    readonly actionsButton: Locator;
    readonly businessNameInput: Locator;
    readonly cifInput: Locator;
    readonly addressInput: Locator;
    readonly zipCodeInput: Locator;
    readonly cityInput: Locator;
    readonly countryDropdown: Locator;
    readonly countryOptionAndorra: Locator;
    readonly languageDropdown: Locator;
    readonly languageOptionEnglish: Locator;
    readonly createButton: Locator;
    readonly successAlert: Locator;
    readonly searchInput: Locator;
    readonly tableBody: Locator;
    readonly deleteInstitutionButton: Locator;
    readonly deleteButton: Locator;
    readonly acceptButton: Locator;

    constructor(page: Page) {
        super(page);
        this.actionsButton = page.locator('#add-company-button, button:has(.ri-add-line), .MuiFab-root').or(page.getByRole('button', { name: /Actions|Acciones/i })).first();
        this.businessNameInput = page.locator('#business-name');
        this.cifInput = page.locator('#addSociedadCIF');
        this.addressInput = page.locator('#addSociedadDireccion');
        this.zipCodeInput = page.locator('#addSociedadCP');
        this.cityInput = page.locator('#addSociedadLocalidad');
        this.countryDropdown = page.getByText('SpainCountry');
        this.countryOptionAndorra = page.getByText('Andorra');
        this.languageDropdown = page.getByRole('combobox', { name: /Main language|Idioma principal/i })
            .or(page.locator('#mui-component-select-idLanguage, [aria-labelledby*="idLanguage" i]'))
            .or(page.locator('.MuiFormControl-root').filter({ hasText: /Main language|Idioma principal/i }))
            .or(page.getByText(/EspañolMain language|EspañolIdioma principal/i))
            .first();
        this.languageOptionEnglish = page.getByRole('option', { name: 'English' })
            .or(page.getByRole('listbox').getByText('English'))
            .or(page.locator('[role="option"]').filter({ hasText: 'English' }))
            .first();
        this.createButton = page.getByRole('button', { name: ' Create' });
        this.successAlert = page.getByRole('alert');
        this.searchInput = page.getByRole('textbox', { name: /Search entity|Search institution|Buscar/i })
            .or(page.locator('input[placeholder*="Search" i]'))
            .or(page.locator('input[placeholder*="Buscar" i]'))
            .first();
        this.tableBody = page.locator('tbody');
        this.deleteInstitutionButton = page.getByRole('button', { name: '' });
        this.deleteButton = page.getByRole('button', { name: ' Delete' });
        this.acceptButton = page.getByRole('button', { name: 'Accept' });
    }

    async openCreateInstitutionForm() {
        await test.step('Open create institution form', async () => {
            await this.actionsButton.click();
        });
    }

    async fillInstitutionDetails(data: InstitutionData) {
        await test.step(`Fill institution details: ${data.name}`, async () => {
            await this.businessNameInput.fill(data.name);
            await this.cifInput.fill(data.cif);
            await this.addressInput.fill(data.address);
            await this.zipCodeInput.fill(data.zipCode);

            await this.countryDropdown.click();
            await this.countryOptionAndorra.click();

            await this.cityInput.fill(data.city);

            await this.dismissToastOrModal();
            await this.languageDropdown.click();
            await this.languageOptionEnglish.click();
        });
    }

    async submitCreateForm() {
        await test.step('Submit create form', async () => {
            await this.createButton.click();
        });
    }

    async verifySuccessAlert() {
        await test.step('Verify institution created success alert', async () => {
            await expect(this.successAlert).toContainText(MESSAGES.INSTITUTION_CREATED);
        });
    }

    async searchInstitution(name: string) {
        await test.step(`Search for institution: ${name}`, async () => {
            await this.navigateToInstitutions();
            await this.searchInput.click();
            await this.searchInput.fill(name);
        });
    }

    async verifyInstitutionInTable(name: string) {
        await test.step(`Verify institution "${name}" appears in table`, async () => {
            await expect(this.tableBody).toContainText(name);
        });
    }

    async createInstitution(data: InstitutionData) {
        await test.step(`Create institution: ${data.name}`, async () => {
            await this.openCreateInstitutionForm();
            await this.fillInstitutionDetails(data);
            await this.submitCreateForm();
        });
    }

    async deleteInstitution(name: string) {
        await test.step(`Delete institution: ${name}`, async () => {
            await this.navigateToInstitutions();
            await this.searchInput.click();
            await this.searchInput.fill(name);
            const targetRow = this.page.locator('tbody tr').filter({ hasText: name }).first();
            await targetRow.waitFor({ state: 'visible', timeout: 10000 });
            await targetRow.locator('td:last-child button, button:has(.ri-more-2-line), button:has(.ri-more-fill), button:has(.ri-more-2-fill), button[aria-label*="Actions" i]').first().click();
            await this.page.waitForTimeout(500);
            const deleteOption = this.page.getByRole('button', { name: /Delete|Eliminar/i }).first();
            await deleteOption.waitFor({ state: 'visible', timeout: 5000 });
            await deleteOption.click();
            await this.page.waitForTimeout(500);
            const acceptBtn = this.page.locator('#panel-confirm-button-accept, #modal-button-accept')
                .or(this.page.getByRole('dialog').getByRole('button', { name: /Accept|Delete|Aceptar|Eliminar/i }))
                .first();
            await acceptBtn.waitFor({ state: 'visible', timeout: 5000 });
            await acceptBtn.click();
        });
    }

    async verifyDeleteSuccessAlert() {
        await test.step('Verify institution deleted success alert', async () => {
            await expect(this.successAlert).toContainText(MESSAGES.INSTITUTION_DELETED);
        });
    }

    async verifyNoSearchResults() {
        await test.step('Verify no institution search results', async () => {
            await this.page.waitForTimeout(1000);
            await expect(this.tableBody).not.toContainText(/Automation Institution/i, { timeout: 5000 });
        });
    }

    async verifyInstitutionNotInTable(name: string) {
        await test.step(`Verify institution "${name}" is NOT in the table`, async () => {
            await this.page.waitForTimeout(1000);
            await expect(this.tableBody).not.toContainText(name, { timeout: 5000 });
        });
    }

    /**
     * Verifies that the Organization icon differs from the Entity icon (XR-2299).
     */
    async verifyOrganizationAndEntityIconsDiffer() {
        await test.step('Verify Organization icon is different from Entity icon', async () => {
            const orgRow = this.page.locator('table tbody tr').filter({ hasText: /Organization|Organización/i }).first();
            const entityRow = this.page.locator('table tbody tr').filter({ hasText: /Entity|Entidad/i }).first();

            await expect(orgRow).toBeVisible({ timeout: 10000 });
            await expect(entityRow).toBeVisible({ timeout: 10000 });

            const orgIconHtml = await orgRow.locator('td:first-child .MuiAvatar-root, td:first-child i, td:first-child img').first().innerHTML();
            const entityIconHtml = await entityRow.locator('td:first-child .MuiAvatar-root, td:first-child i, td:first-child img').first().innerHTML();

            expect(orgIconHtml).not.toBe(entityIconHtml);
        });
    }

    /**
     * Sorts the institutions table by Name column and verifies order changes (XR-2300).
     */
    async sortByNameColumn() {
        await test.step('Sort institutions by Name column', async () => {
            const nameTh = this.page.locator('table thead th:first-child .cbx-table-sort-label, table thead th:first-child').first();
            await nameTh.waitFor({ state: 'visible', timeout: 10000 });

            const getFirstRowName = async () => {
                return (await this.page.locator('table tbody tr:first-child td:first-child').innerText().catch(() => '')).trim();
            };

            const initialFirst = await getFirstRowName();
            await nameTh.click();
            await this.page.waitForTimeout(1000);
            const afterFirst = await getFirstRowName();

            expect(afterFirst).toBeTruthy();
            expect(afterFirst).not.toBe(initialFirst);

            // Toggle back
            await nameTh.click();
            await this.page.waitForTimeout(1000);
            const returnedFirst = await getFirstRowName();
            expect(returnedFirst).toBe(initialFirst);
        });
    }

    /**
     * Sorts the institutions table by Level column and verifies order changes (XR-2301).
     */
    async sortByLevelColumn() {
        await test.step('Sort institutions by Level column', async () => {
            const levelTh = this.page.locator('table thead th').filter({ hasText: /Level|Nivel/i }).first();
            await levelTh.waitFor({ state: 'visible', timeout: 10000 });

            const getFirstRowLevel = async () => {
                return (await this.page.locator('table tbody tr:first-child td:nth-child(4)').innerText().catch(() => '')).trim();
            };

            const initialLevel = await getFirstRowLevel();
            await levelTh.click();
            await this.page.waitForTimeout(1000);
            const afterLevel = await getFirstRowLevel();

            // Toggle to opposite direction
            await levelTh.click();
            await this.page.waitForTimeout(1000);
            const toggledLevel = await getFirstRowLevel();

            expect(toggledLevel).toBeTruthy();
            expect([initialLevel, afterLevel, toggledLevel].some(lvl => /Organization|Organización|Entity|Entidad/i.test(lvl))).toBe(true);
        });
    }

    /**
     * Verifies that the Institutions view contains all expected columns and fields (XR-2302).
     */
    async verifyInstitutionsTableFields() {
        await test.step('Verify Institutions table contains all required fields', async () => {
            await expect(this.searchInput).toBeVisible({ timeout: 10000 });

            const headers = this.page.locator('table thead th');
            await expect(headers.filter({ hasText: /Name|Nombre/i })).toBeVisible({ timeout: 5000 });
            await expect(headers.filter({ hasText: /\bId\b/i })).toBeVisible({ timeout: 5000 });
            await expect(headers.filter({ hasText: /External ID|ID externo/i })).toBeVisible({ timeout: 5000 });
            await expect(headers.filter({ hasText: /Level|Nivel/i })).toBeVisible({ timeout: 5000 });

            // Wait for rows to load from network
            const firstRow = this.page.locator('table tbody tr').first();
            await firstRow.waitFor({ state: 'visible', timeout: 10000 });
            const rowCount = await this.page.locator('table tbody tr').count();
            expect(rowCount).toBeGreaterThan(0);
        });
    }

    /**
     * Observes header and verifies that External ID label is displayed properly in Institutions table (OVAC-4959).
     */
    async verifyExternalIdHeaderDisplayed() {
        await test.step('Observe header and verify External ID label is displayed properly in Institutions table', async () => {
            const externalIdHeader = this.page.locator('table thead th, .MuiTableHead-root th')
                .filter({ hasText: /External ID|ID externo/i })
                .first();
            await expect(externalIdHeader).toBeVisible({ timeout: 10000 });
        });
    }

    /**
     * Verifies that the Level column displays correct values (Entity / Organization) (XR-2303).
     */
    async verifyLevelColumnValues() {
        await test.step('Verify Level column displays correct values', async () => {
            // Wait for rows to load from network
            const firstRow = this.page.locator('table tbody tr').first();
            await firstRow.waitFor({ state: 'visible', timeout: 10000 });

            const levelCells = this.page.locator('table tbody tr td:nth-child(4)');
            const count = await levelCells.count();
            expect(count).toBeGreaterThan(0);

            const values: string[] = [];
            for (let i = 0; i < count; i++) {
                const text = (await levelCells.nth(i).innerText()).trim();
                values.push(text);
                expect(text).toMatch(/^(Entity|Organization|Entidad|Organización)$/i);
            }

            expect(values.some(v => /Entity|Entidad/i.test(v))).toBe(true);
            expect(values.some(v => /Organization|Organización/i.test(v))).toBe(true);
        });
    }

    /**
     * Opens details/settings for a specific institution (XR-2697).
     */
    async openInstitutionDetails(name: string) {
        await test.step(`Open institution details for "${name}"`, async () => {
            const isQADev = /QA DEV/i.test(name);
            const searchPattern = isQADev ? /QA DEV|Grupo Castelar/i : new RegExp(name, 'i');
            let row = this.page.locator('table tbody tr').filter({ hasText: searchPattern }).first();
            if (!await row.isVisible({ timeout: 2000 }).catch(() => false)) {
                await this.searchInstitution(isQADev ? 'Grupo Castelar' : name);
                row = this.page.locator('table tbody tr').filter({ hasText: searchPattern }).first();
            }
            if (!await row.isVisible({ timeout: 2000 }).catch(() => false)) {
                await this.searchInstitution(name);
                row = this.page.locator('table tbody tr').filter({ hasText: searchPattern }).first();
            }
            await row.waitFor({ state: 'visible', timeout: 10000 });

            // Click 3-dots menu button on row to access Edit option
            const threeDotsBtn = row.locator('td:last-child button, button:has(.ri-more-2-line), button:has(.ri-more-fill), button:has(.ri-more-2-fill), button[aria-label*="Botón" i]').first();
            await threeDotsBtn.waitFor({ state: 'visible', timeout: 5000 });
            await threeDotsBtn.click();
            await this.page.waitForTimeout(400);

            // Click Edit button in row dropdown menu
            const editBtn = this.page.getByRole('button', { name: /Edit|Editar/i })
                .or(this.page.locator('[role="menuitem"]:has-text("Edit"), button:has-text("Edit")'))
                .first();
            await editBtn.waitFor({ state: 'visible', timeout: 5000 });
            await editBtn.click();

            await this.page.waitForURL(/\/companies\/edit\/\d+/i, { timeout: 10000 });
        });
    }

    /**
     * Navigates to Administration -> Agenda tab (XR-2697).
     */
    async navigateToAdministrationAgenda() {
        await test.step('Navigate to Administration -> Agenda tab', async () => {
            const adminTab = this.page.getByRole('button', { name: /Administration|Administración/i }).first();
            await adminTab.waitFor({ state: 'visible', timeout: 10000 });
            await adminTab.click();
            await this.page.waitForTimeout(1000);

            if (!this.page.url().includes('/administration/schedule')) {
                const agendaTab = this.page.locator('button[role="tab"]:has-text("Agenda"), [role="tab"]:has-text("Agenda"), button:has-text("Agenda")').first();
                await agendaTab.waitFor({ state: 'visible', timeout: 10000 });
                await agendaTab.click();
            }
            await this.page.waitForURL(/\/administration\/schedule/i, { timeout: 10000 });
            await this.page.locator('table tbody tr').first().waitFor({ state: 'visible', timeout: 10000 });
        });
    }

    /**
     * Opens the edit drawer for the first available schedule period (XR-2697).
     */
    async openEditSchedulePeriod() {
        await test.step('Open edit schedule period drawer', async () => {
            const firstRow = this.page.locator('table tbody tr').first();
            await firstRow.waitFor({ state: 'visible', timeout: 10000 });
            const threeDotsBtn = firstRow.locator('td:last-child button, button:has(.ri-more-2-line), button:has(.ri-more-fill), button:has(.ri-more-2-fill), button[aria-label*="Botón" i]').first();
            await threeDotsBtn.click();
            await this.page.waitForTimeout(400);

            const editOption = this.page.getByRole('button', { name: /Edit|Editar/i })
                .or(this.page.locator('#schedule_edit_button, button:has-text("Edit"), [role="menuitem"]:has-text("Edit"), [role="button"]:has-text("Edit")'))
                .first();
            await editOption.waitFor({ state: 'visible', timeout: 5000 });
            await editOption.click();
            await this.page.waitForTimeout(600);
        });
    }

    /**
     * Sets the Minimum notice (advance time) in the schedule period edit drawer (XR-2697).
     */
    async setMinimumAdvanceNotice(value: string | number) {
        await test.step(`Set minimum advance notice to ${value}`, async () => {
            const noticeInput = this.page.getByRole('spinbutton', { name: /Minimum notice|Antelación mínima/i })
                .or(this.page.locator('input[name*="notice" i]'))
                .or(this.page.locator('.MuiFormControl-root').filter({ hasText: /Minimum notice|Antelación mínima/i }).locator('input'))
                .first();
            await noticeInput.waitFor({ state: 'visible', timeout: 10000 });
            await noticeInput.clear();
            await noticeInput.fill(value.toString());
        });
    }

    /**
     * Saves the schedule period adjustments (XR-2697).
     */
    async saveSchedulePeriod() {
        await test.step('Save schedule period adjustments', async () => {
            const saveBtn = this.page.getByRole('button', { name: /Save|Guardar/i })
                .or(this.page.locator('#panel-confirm-button-accept, button:has-text("SAVE"), button:has-text("GUARDAR")'))
                .first();
            await saveBtn.waitFor({ state: 'visible', timeout: 5000 });
            await saveBtn.click();
            await this.page.waitForTimeout(1000);
            await this.dismissToastOrModal();
        });
    }

    /**
     * Navigates to the company settings page (XR-2605 / XR-1626).
     */
    async navigateToCompanySettings(companyId: number = 1112) {
        await test.step(`Navigate to company #${companyId} settings page`, async () => {
            await this.page.goto(`https://qa.ovac.pre.councilbox.com/company/${companyId}/companies/edit/${companyId}/general/settings`);
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();
        });
    }

    /**
     * Gets the Support Email from company settings (XR-2605).
     */
    async getSupportEmail(): Promise<string> {
        return await test.step('Get current support email', async () => {
            const supportEmailInput = this.page.locator('.cbx-inputText-container')
                .filter({ hasText: /Support email|Email de soporte/i })
                .locator('input')
                .first();
            await supportEmailInput.waitFor({ state: 'visible', timeout: 10000 });
            return await supportEmailInput.inputValue();
        });
    }

    /**
     * Updates the Support Email in company settings (XR-2605).
     */
    async updateSupportEmail(email: string) {
        await test.step(`Update support email to: ${email}`, async () => {
            const supportEmailInput = this.page.locator('.cbx-inputText-container')
                .filter({ hasText: /Support email|Email de soporte/i })
                .locator('input')
                .first();
            await supportEmailInput.waitFor({ state: 'visible', timeout: 10000 });
            await supportEmailInput.fill(email);
            await supportEmailInput.blur();
        });
    }

    /**
     * Saves the company settings form (XR-1626 / XR-2605).
     */
    async saveCompanySettings() {
        await test.step('Save company settings', async () => {
            const saveBtn = this.page.getByRole('button', { name: /^Save$|^Guardar$/i })
                .or(this.page.locator('button').filter({ hasText: /^Save$|^Guardar$/i }))
                .first();
            await saveBtn.waitFor({ state: 'visible', timeout: 5000 });
            await saveBtn.click();
            await this.page.waitForTimeout(1000);
        });
    }

    /**
     * Verifies the success alert after saving company settings (XR-1626 / XR-2605).
     */
    async verifyCompanySettingsSavedAlert() {
        await test.step('Verify company settings saved alert', async () => {
            const alert = this.page.locator('[role="alert"], [class*="snackbar"], [class*="toast"]').first();
            await expect(alert).toBeVisible({ timeout: 10000 });
            await expect(alert).toContainText(/saved successfully|guardado con éxito|correctamente/i);
        });
    }

    /**
     * Gets the company Name input value (OVAC-5741 / XR-1630).
     */
    async getCompanyName(): Promise<string> {
        return await test.step('Get company Name', async () => {
            const input = this.page.locator('input[name*="name" i], [id*="name" i]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /^Name|^Nombre/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            return await input.inputValue();
        });
    }

    /**
     * Updates the company Name input (OVAC-5741 / XR-1630).
     */
    async updateCompanyName(name: string) {
        await test.step(`Update company name to: ${name}`, async () => {
            const input = this.page.locator('input[name*="name" i], [id*="name" i]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /^Name|^Nombre/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            await input.fill(name);
            await input.blur();
        });
    }

    /**
     * Gets the company VAT NO/CIF input value (OVAC-5746 / XR-1629).
     */
    async getCompanyCif(): Promise<string> {
        return await test.step('Get company VAT NO/CIF', async () => {
            const input = this.page.locator('input[name*="cif" i], input[name*="vat" i], input[name*="tax" i], [id*="cif" i], [id*="vat" i]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /CIF|VAT|TAX/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            return await input.inputValue();
        });
    }

    /**
     * Updates the company VAT NO/CIF input (OVAC-5746 / XR-1629).
     */
    async updateCompanyCif(cif: string) {
        await test.step(`Update company CIF to: ${cif}`, async () => {
            const input = this.page.locator('input[name*="cif" i], input[name*="vat" i], input[name*="tax" i], [id*="cif" i], [id*="vat" i]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /CIF|VAT|TAX/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            await input.fill(cif);
            await input.blur();
        });
    }

    /**
     * Gets the contact e-mail input value (OVAC-5745 / XR-1628).
     */
    async getCompanyContactEmail(): Promise<string> {
        return await test.step('Get company contact email', async () => {
            const input = this.page.locator('input[name*="email" i], [id*="email" i], input[type="email"]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /email|correo/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            return await input.inputValue();
        });
    }

    /**
     * Updates the contact e-mail input (OVAC-5745 / XR-1628).
     */
    async updateCompanyContactEmail(email: string) {
        await test.step(`Update company contact email to: ${email}`, async () => {
            const input = this.page.locator('input[name*="email" i], [id*="email" i], input[type="email"]').or(
                this.page.locator('.cbx-inputText-container, .MuiFormControl-root').filter({ hasText: /email|correo/i }).locator('input')
            ).first();
            await input.waitFor({ state: 'visible', timeout: 10000 });
            await input.fill(email);
            await input.blur();
        });
    }

    /**
     * Navigates to Customization -> Notifications tab (OVAC-5224).
     */
    async navigateToCustomizationNotifications(companyId: number = 1112) {
        await test.step(`Navigate to Customization -> Notifications for company #${companyId}`, async () => {
            await this.page.goto(resolveCompanyUrl(companyId, `companies/edit/${companyId}/personalization/notifications`));
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();
        });
    }

    /**
     * Verifies default notification template text for a given notification type (OVAC-5714, OVAC-5726, OVAC-5678, OVAC-5674, OVAC-5672).
     */
    async verifyNotificationDefaultTemplateText(notificationName: RegExp | string, expectedKeywords: (RegExp | string)[]) {
        await test.step(`Verify default template text for notification: ${notificationName}`, async () => {
            await this.navigateToCustomizationNotifications(1112);

            const pattern = typeof notificationName === 'string' ? new RegExp(notificationName, 'i') : notificationName;
            const notifRow = this.page.locator('tr, li, [role="row"]')
                .filter({ has: this.page.locator('td:first-child div, td:first-child p, td:first-child span').filter({ hasText: pattern }) })
                .first();
            await notifRow.waitFor({ state: 'visible', timeout: 15000 });

            // Click the title cell link to open the notification edit page
            const titleLink = notifRow.locator('td').first().locator('div').filter({ hasText: pattern }).first();
            await titleLink.waitFor({ state: 'visible', timeout: 10000 });
            await titleLink.click();
            await this.page.waitForLoadState('networkidle');
            await this.page.waitForTimeout(1000);

            // Assert editor loaded with non-empty subject/header and matches expected template tokens
            const headerInput = this.page.locator('.cbx-inputText-container input, input.cbx-inputText-input, input[id*="cbx-inputText"]').first();
            await expect(headerInput).toBeVisible({ timeout: 10000 });
            const headerVal = await headerInput.inputValue();
            expect(headerVal.length).toBeGreaterThan(0);

            // Check body / editor content (.ql-editor or contenteditable)
            const bodyContent = this.page.locator('.ql-editor, [contenteditable="true"]').first();
            await expect(bodyContent).toBeVisible({ timeout: 10000 });
            const bodyText = await bodyContent.innerText();
            expect(bodyText.length).toBeGreaterThan(0);

            const combined = `${headerVal} ${bodyText}`;
            for (const kw of expectedKeywords) {
                if (typeof kw === 'string') {
                    expect(combined).toContain(kw);
                } else {
                    expect(combined).toMatch(kw);
                }
            }
        });
    }

    /**
     * Verifies error message display when attempting to create a schedule without assigned professionals (OVAC-5185).
     */
    async verifyScheduleCreationWithoutProfessionalsShowsError(companyId: number = 1112) {
        await test.step('Verify error message display when attempting to create schedule without assigned professionals', async () => {
            await this.dismissToastOrModal();
            await this.page.goto(resolveCompanyUrl(companyId, `companies/edit/${companyId}/administration/schedule`));
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();

            // In schedule table, click add available period button
            const addBtn = this.page.locator('button:has(.ri-add-line), button:has-text("Add"), button:has-text("Añadir")').first();
            await addBtn.waitFor({ state: 'visible', timeout: 10000 });
            await addBtn.click();
            await this.page.waitForTimeout(500);

            // In dropdown menu, select "Available period"
            const periodOption = this.page.getByRole('button', { name: /Available period|Período disponible/i })
                .or(this.page.locator('[role="menu"] button:has-text("Available period"), [role="menuitem"]:has-text("Available period")'))
                .first();
            if (await periodOption.isVisible({ timeout: 5000 }).catch(() => false)) {
                await periodOption.click();
                await this.page.waitForTimeout(1000);
            }

            // Assert drawer or dialog is opened
            const drawer = this.page.locator('.MuiDrawer-root:visible, .MuiDialog-root:visible, [role="dialog"]:visible').last();
            await expect(drawer).toBeVisible({ timeout: 10000 });

            // Inside drawer, click "Add" / "Save" button without assigning professionals
            const saveBtn = drawer.getByRole('button', { name: /^Add$|^Añadir$|^Save$|^Guardar$/i })
                .or(drawer.locator('button[type="submit"]'))
                .last();
            if (await saveBtn.isVisible({ timeout: 5000 }).catch(() => false)) {
                await saveBtn.click();
                await this.page.waitForTimeout(1000);
            }

            // Assert alert, error message, or required validation is displayed
            const alertOrError = this.page.locator('.MuiAlert-root, [role="alert"], .cbx-Alert, .Mui-error, [aria-invalid="true"]').first();
            await expect(alertOrError).toBeVisible({ timeout: 10000 });

            // Close drawer with Escape
            await this.page.keyboard.press('Escape');
            await this.page.waitForTimeout(500);
        });
    }

    /**
     * Gets the company Main language setting text (OVAC-5768 / XR-1627).
     */
    async getCompanyMainLanguage(): Promise<string> {
        return await test.step('Get company main language', async () => {
            const langContainer = this.page.locator('.cbx-inputText-container, .MuiFormControl-root')
                .filter({ hasText: /Main language|Idioma principal/i })
                .first();
            await langContainer.waitFor({ state: 'visible', timeout: 10000 });
            return (await langContainer.innerText()).trim();
        });
    }

    /**
     * Updates the company Main language selector (OVAC-5768 / XR-1627).
     */
    async updateCompanyMainLanguage(languageName: string = 'English') {
        await test.step(`Update company main language to: "${languageName}"`, async () => {
            const langContainer = this.page.locator('.cbx-inputText-container, .MuiFormControl-root')
                .filter({ hasText: /Main language|Idioma principal/i })
                .first();
            await langContainer.waitFor({ state: 'visible', timeout: 10000 });
            const combobox = langContainer.locator('[role="combobox"], [role="button"], input').first();
            await combobox.click({ force: true });
            await this.page.waitForTimeout(500);

            const option = this.page.locator('[role="option"], li.MuiMenuItem-root')
                .filter({ hasText: new RegExp(`^${languageName}$`, 'i') })
                .first();
            await option.waitFor({ state: 'visible', timeout: 5000 });
            await option.click();
            await this.page.waitForTimeout(500);
        });
    }

    /**
     * Navigates to Customization -> Appearance tab (OVAC-5769 / XR-1632).
     */
    async navigateToCustomizationAppearance(companyId: number = 1112) {
        await test.step(`Navigate to Customization -> Appearance for company #${companyId}`, async () => {
            await this.page.goto(`https://qa.ovac.pre.councilbox.com/company/${companyId}/companies/edit/${companyId}/personalization/appearance`);
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();
        });
    }

    /**
     * Uploads an organization logo in the Appearance settings (OVAC-5769 / XR-1632).
     */
    async uploadOrganizationLogo(filePath: string = 'test-data/test-logo.png') {
        await test.step('Upload organization logo in appearance settings', async () => {
            const logoInput = this.page.locator('#raised-button-file-subdomain-logo');
            await expect(logoInput).toBeAttached();
            const resolvedPath = path.resolve(filePath);
            await logoInput.setInputFiles(resolvedPath);
            await this.page.waitForTimeout(1000);
        });
    }

    /**
     * Verifies Entity header screen informations: icon, name, type, status, actions menu (OVAC-5180).
     */
    async verifyEntitiesHeadingInformation(companyId: number = 1112) {
        await test.step('Verify entity header screen informations: icon, name, type, status, actions menu', async () => {
            await this.page.goto(`https://qa.ovac.pre.councilbox.com/company/${companyId}/companies/edit/${companyId}`);
            await this.page.waitForLoadState('domcontentloaded');
            await this.dismissToastOrModal();

            // 1. Verify entity name (heading level 1)
            const entityHeading = this.page.getByRole('heading', { level: 1 }).filter({ hasNotText: /^Entities$/i }).first();
            await expect(entityHeading).toBeVisible({ timeout: 10000 });

            // 2. Verify entity icon
            const entityIcon = this.page.locator('img[alt*="Logo" i], .ri-building-line, .ri-government-line, .cbx-IconButton, i[class*="ri-"]').first();
            await expect(entityIcon).toBeVisible({ timeout: 5000 });

            // 3. Verify type (Organization or entity / Organización o entidad)
            const typeIndicator = this.page.locator('p:visible, span:visible, div:visible').filter({ hasText: /^Organization$|^Organización$|^Entity$|^Entidad$/i }).first();
            await expect(typeIndicator).toBeVisible({ timeout: 5000 });

            // 4. Verify Actions / Save button
            const saveBtn = this.page.getByRole('button', { name: /Save|Guardar/i }).first();
            await expect(saveBtn).toBeVisible({ timeout: 5000 });
        });
    }

    /**
     * Navigates to company settings and verifies the Consumptions section contains Roles and External Services/Storage data (OVAC-5377).
     */
    async verifyConsumptionsSectionRefined(companyId: number = 1112) {
        await test.step(`Verify Consumptions section on company #${companyId} settings`, async () => {
            await this.page.goto(resolveCompanyUrl(companyId, `companies/edit/${companyId}`));
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();

            const consumptionsHeading = this.page.getByRole('heading', { name: /^Consumptions$|^Consumos$/i }).first();
            await expect(consumptionsHeading).toBeVisible({ timeout: 15000 });

            // External Services metrics section (SMS, Uanataca, Autofirma, Biometry)
            await expect(this.page.getByText(/^SMS$/i).first()).toBeVisible({ timeout: 10000 });
            await expect(this.page.getByText(/Uanataca/i).first()).toBeVisible({ timeout: 10000 });
            await expect(this.page.getByText(/Autofirma/i).first()).toBeVisible({ timeout: 10000 });
            await expect(this.page.getByText(/Biometry|Biometría/i).first()).toBeVisible({ timeout: 10000 });

            // Roles consumption section (Admin agent, Global administrator, Kiosk)
            await expect(this.page.getByText(/^Roles$/i).first()).toBeVisible({ timeout: 10000 });
            await expect(this.page.getByText(/Admin agent|Agente administrador/i).first()).toBeVisible({ timeout: 10000 });

            // Date filter selector in Consumptions
            const dateCombo = this.page.getByRole('combobox', { name: /^Date$|^Fecha$/i }).first();
            await expect(dateCombo).toBeVisible({ timeout: 5000 });
        });
    }

    /**
     * Edits an existing entity via the Entities list Edit action and verifies persistence (OVAC-5298).
     */
    async editInstitutionAndVerify(currentName: string, updatedName: string) {
        await test.step(`Edit entity "${currentName}" to "${updatedName}"`, async () => {
            await this.searchInstitution(currentName);
            const row = this.page.locator('table tbody tr').filter({ hasText: currentName }).first();
            await row.waitFor({ state: 'visible', timeout: 10000 });

            const actionBtn = row.locator('td:last-child button, button:has(.ri-more-2-line), button:has(.ri-more-fill), button:has(.ri-more-2-fill)').first();
            await actionBtn.click();

            const editOption = this.page.getByRole('button', { name: /Edit|Editar/i })
                .or(this.page.getByRole('menuitem', { name: /Edit|Editar/i }))
                .first();
            await editOption.waitFor({ state: 'visible', timeout: 5000 });
            await editOption.click();
            await this.page.waitForURL(/\/companies\/edit\/\d+/i, { timeout: 15000 });
            await this.dismissToastOrModal();

            await this.updateCompanyName(updatedName);
            await this.saveCompanySettings();
            await this.verifyCompanySettingsSavedAlert();

            await this.searchInstitution(updatedName);
            await this.verifyInstitutionInTable(updatedName);
        });
    }

    /**
     * Bans an existing entity via the Entities list Ban action and verifies it is banned/removed from active list (OVAC-5261).
     */
    async banInstitutionAndVerify(name: string) {
        await test.step(`Ban entity "${name}" and verify it is removed from active list`, async () => {
            await this.searchInstitution(name);
            const row = this.page.locator('table tbody tr').filter({ hasText: name }).first();
            await row.waitFor({ state: 'visible', timeout: 10000 });

            const actionBtn = row.locator('td:last-child button, button:has(.ri-more-2-line), button:has(.ri-more-fill), button:has(.ri-more-2-fill), button:has-text("button")').last();
            await actionBtn.click();

            const banOption = this.page.getByRole('button', { name: /Ban|Bloquear/i })
                .or(this.page.getByRole('menuitem', { name: /Ban|Bloquear/i }))
                .first();
            await banOption.waitFor({ state: 'visible', timeout: 5000 });
            await banOption.click();

            const confirmDialog = this.page.locator('#modal, .MuiDialog-root, [role="dialog"]').filter({ hasText: /Ban|Bloquear|Accept|Aceptar/i }).first();
            await expect(confirmDialog).toBeVisible({ timeout: 10000 });
            const acceptBtn = confirmDialog.locator('#modal-button-accept, #alert-confirm-button-accept')
                .or(confirmDialog.getByRole('button', { name: /^OK$|^Accept$|^Aceptar$|^Ban$|^Bloquear$/i }))
                .last();
            await acceptBtn.click();
            await expect(confirmDialog).toBeHidden({ timeout: 15000 });
            await this.page.waitForTimeout(1000);

            // Verify banned entity no longer appears in the active Entities table
            await this.searchInstitution(name);
            await this.verifyInstitutionNotInTable(name);
        });
    }

    /**
     * Navigates to Customization -> Appearance and verifies the Translations section and title edit modal (OVAC-4912).
     */
    async verifyTranslationsSectionInAppearance(companyId: number = 1112) {
        await test.step(`Verify Translations section in Appearance tab for company #${companyId}`, async () => {
            await this.page.goto(resolveCompanyUrl(companyId, `companies/edit/${companyId}/personalization/appearance`));
            await this.page.waitForLoadState('networkidle');
            await this.dismissToastOrModal();

            const translationsHeading = this.page.getByRole('heading', { name: /Translations|Traducciones/i })
                .or(this.page.getByText(/Translations|Traducciones/i))
                .first();
            await translationsHeading.scrollIntoViewIfNeeded();
            await expect(translationsHeading).toBeVisible({ timeout: 10000 });

            // Verify at least one translation row/item and Edit action opens title edit modal
            const transRow = this.page.locator('table tbody tr, [role="row"]').filter({ has: this.page.locator('button') }).first();
            await transRow.waitFor({ state: 'visible', timeout: 10000 });
            await transRow.locator('button').last().click();
            await this.page.waitForTimeout(400);

            const editOption = this.page.getByRole('button', { name: /Edit|Editar/i })
                .or(this.page.getByRole('menuitem', { name: /Edit|Editar/i }))
                .first();
            await editOption.waitFor({ state: 'visible', timeout: 5000 });
            await editOption.click();

            const editDialog = this.page.locator('[role="dialog"], .MuiDrawer-root:visible').last();
            await expect(editDialog).toBeVisible({ timeout: 10000 });
            await expect(editDialog.locator('input, textarea').first()).toBeVisible({ timeout: 5000 });
            await this.page.keyboard.press('Escape');
        });
    }
}
