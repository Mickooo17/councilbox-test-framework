import { Page, Locator, test } from '@playwright/test';

export class BasePage {
    readonly closeModalButton: Locator;
    readonly institutionsButton: Locator;
    readonly templatesButton: Locator;
    readonly proceduresButton: Locator;
    readonly documentationButton: Locator;
    readonly usersButton: Locator;
    readonly appointmentsButton: Locator;
    readonly governmentIcon: Locator;
    readonly qaDevMenuItem: Locator;

    constructor(public page: Page) {
        this.closeModalButton = page.locator('.MuiButtonBase-root.MuiIconButton-root.closeIcon');
        this.appointmentsButton = page.locator('a[href*="/company/"][href*="appointments"]').or(page.locator('a[href*="/company/"]')).or(page.getByRole('button', { name: /Appointments|Citas/i })).or(page.locator('.ri-calendar-line, [class*="calendar"]').locator('..')).first();
        this.institutionsButton = page.locator('a[href*="/companies"]').or(page.getByRole('button', { name: /Entities|Institutions|Entidades|Instituciones/i })).first();
        this.templatesButton = page.locator('a[href*="/drafts"]').or(page.getByRole('button', { name: /Templates|Plantillas/i })).first();
        this.proceduresButton = page.locator('a[href*="/procedures"]').or(page.getByRole('button', { name: /Procedures|Procedimientos/i })).first();
        this.documentationButton = page.locator('a[href*="/documentation"]').or(page.locator('#documentation-link')).first();
        this.usersButton = page.locator('a[href*="/users"]').or(page.getByRole('button', { name: /Users|Usuarios/i })).first();
        this.governmentIcon = page.locator('.ri-government-line, [class*="government"]').first();
        this.qaDevMenuItem = page.getByRole('menuitem', { name: /company-logo QA DEV|QA DEV|Grupo Castelar/i })
            .or(page.locator('[role="menuitem"]').filter({ hasText: /QA DEV|Grupo Castelar/i }))
            .or(page.getByText(/QA DEV|Grupo Castelar/i))
            .first();
    }

    async dismissModal() {
        await test.step('Dismiss modal dialog', async () => {
            const modal = this.page.locator('#alert-confirm, .MuiDialog-root, #modal');
            if (await modal.first().isVisible({ timeout: 2000 }).catch(() => false)) {
                const actionBtn = modal.first().locator('button').first();
                if (await actionBtn.isVisible({ timeout: 1000 }).catch(() => false)) {
                    await actionBtn.click();
                } else {
                    await this.page.keyboard.press('Escape');
                }
                await modal.first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
            }
        });
    }

    async dismissToastOrModal() {
        await test.step('Dismiss toast or modal banner if present', async () => {
            const closeBtn = this.page.locator(`
                .slide-in button,
                .slide-in [class*="close"],
                .slide-in [aria-label*="close" i],
                .MuiButtonBase-root.MuiIconButton-root.closeIcon,
                button.closeIcon,
                [class*="toast"] button,
                [class*="snackbar"] button,
                button[aria-label="close" i],
                button[aria-label="Close" i]
            `).first();

            if (await closeBtn.isVisible({ timeout: 500 }).catch(() => false)) {
                await closeBtn.click({ timeout: 1000, force: true }).catch(() => {});
            }

            const versionModal = this.page.locator('.MuiDialog-root, [role="dialog"], .cbx-Modal-container').filter({ hasText: /New version|Nueva versión/i }).first();
            if (await versionModal.isVisible({ timeout: 500 }).catch(() => false)) {
                const closeBtn = versionModal.locator('button').first();
                if (await closeBtn.isVisible().catch(() => false)) {
                    await closeBtn.click().catch(() => {});
                } else {
                    await this.page.keyboard.press('Escape');
                }
            }

            await this.page.evaluate(() => {
                document.querySelectorAll('.slide-in, .cbx-dropdown-backdrop, .cbx-dropdown-presentation, [class*="Toastify__toast"], #modal.cbx-Modal-container, .cbx-Modal-backdrop, .MuiDialog-root, .MuiBackdrop-root').forEach(el => {
                    if (el.textContent?.includes('New version') || el.classList.contains('MuiBackdrop-root') || el.classList.contains('cbx-Modal-backdrop')) {
                        (el as HTMLElement).remove();
                    }
                });
            }).catch(() => {});
        });
    }

    async selectQADevCompany() {
        await test.step('Select QA DEV company', async () => {
            await this.dismissToastOrModal();
            const isMenuOpen = await this.qaDevMenuItem.isVisible({ timeout: 500 }).catch(() => false);
            if (!isMenuOpen) {
                await this.governmentIcon.click();
            }
            await this.qaDevMenuItem.waitFor({ state: 'visible', timeout: 10000 });
            await this.qaDevMenuItem.click();
            await this.page.waitForTimeout(1000);
            await this.dismissToastOrModal();
        });
    }

    async navigateToInstitutions() {
        await test.step('Navigate to Institutions page', async () => {
            await this.institutionsButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.institutionsButton.click();
            await this.page.waitForURL(/\/companies/i, { timeout: 10000 }).catch(() => {});
            await this.page.locator('table tbody tr').first().waitFor({ state: 'visible', timeout: 10000 }).catch(() => {});
            await this.page.waitForTimeout(500);
        });
    }

    async navigateToTemplates() {
        await test.step('Navigate to Templates page', async () => {
            await this.templatesButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.templatesButton.click();
        });
    }

    async navigateToProcedures() {
        await test.step('Navigate to Procedures page', async () => {
            await this.proceduresButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.proceduresButton.click();
            await this.page.waitForTimeout(1000);
        });
    }

    async navigateToDocumentation() {
        await test.step('Navigate to Documentation page', async () => {
            await this.documentationButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.documentationButton.click();
        });
    }

    async navigateToUsers() {
        await test.step('Navigate to Users page', async () => {
            await this.usersButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.usersButton.click();
            await this.page.waitForTimeout(1000);
        });
    }

    async navigateToAppointments() {
        await test.step('Navigate to Appointments page', async () => {
            await this.appointmentsButton.waitFor({ state: 'visible', timeout: 10000 });
            await this.appointmentsButton.click();
            await this.page.waitForTimeout(1000);
        });
    }
}
